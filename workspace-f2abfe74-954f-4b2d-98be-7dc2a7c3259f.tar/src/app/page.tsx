"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { PlusCircle, MinusCircle, TrendingUp, TrendingDown, DollarSign, Calendar, User, MapPin, Search, Filter, Download } from "lucide-react";

interface Transaction {
  id: string;
  type: "INCOME" | "EXPENSE";
  amount: number;
  description: string;
  category: string;
  source?: string;
  destination?: string;
  date: string;
  createdAt: string;
}

interface Translations {
  [key: string]: {
    title: string;
    subtitle: string;
    income: string;
    expense: string;
    amount: string;
    description: string;
    category: string;
    source: string;
    destination: string;
    date: string;
    addTransaction: string;
    totalIncome: string;
    totalExpense: string;
    balance: string;
    recentTransactions: string;
    noTransactions: string;
    search: string;
    filter: string;
    allCategories: string;
    allTypes: string;
    fromDate: string;
    toDate: string;
    exportData: string;
    clearFilters: string;
    categories: {
      salary: string;
      business: string;
      investment: string;
      other: string;
      food: string;
      transport: string;
      utilities: string;
      entertainment: string;
      healthcare: string;
      shopping: string;
    };
    language: string;
  };
}

const translations: Translations = {
  en: {
    title: "Income & Expense Manager",
    subtitle: "Track your financial transactions easily",
    income: "Income",
    expense: "Expense",
    amount: "Amount",
    description: "Description",
    category: "Category",
    source: "Source (Who gave?)",
    destination: "Destination (Where spent?)",
    date: "Date",
    addTransaction: "Add Transaction",
    totalIncome: "Total Income",
    totalExpense: "Total Expense",
    balance: "Balance",
    recentTransactions: "Recent Transactions",
    noTransactions: "No transactions yet",
    search: "Search transactions...",
    filter: "Filter",
    allCategories: "All Categories",
    allTypes: "All Types",
    fromDate: "From Date",
    toDate: "To Date",
    exportData: "Export Data",
    clearFilters: "Clear Filters",
    categories: {
      salary: "Salary",
      business: "Business",
      investment: "Investment",
      other: "Other",
      food: "Food",
      transport: "Transport",
      utilities: "Utilities",
      entertainment: "Entertainment",
      healthcare: "Healthcare",
      shopping: "Shopping"
    },
    language: "Language"
  },
  bn: {
    title: "আয় ও ব্যয় ব্যবস্থাপক",
    subtitle: "আপনার আর্থিক লেনদেন সহজে ট্র্যাক করুন",
    income: "আয়",
    expense: "ব্যয়",
    amount: "পরিমাণ",
    description: "বর্ণনা",
    category: "বিভাগ",
    source: "উৎস (কে দিল?)",
    destination: "গন্তব্য (কোথায় খরচ?)",
    date: "তারিখ",
    addTransaction: "লেনদেন যোগ করুন",
    totalIncome: "মোট আয়",
    totalExpense: "মোট ব্যয়",
    balance: "জের",
    recentTransactions: "সাম্প্রতিক লেনদেন",
    noTransactions: "এখনো কোন লেনদেন হয়নি",
    search: "লেনদেন খুঁজুন...",
    filter: "ফিল্টার",
    allCategories: "সব বিভাগ",
    allTypes: "সব ধরন",
    fromDate: "শুরু তারিখ",
    toDate: "শেষ তারিখ",
    exportData: "ডেটা এক্সপোর্ট করুন",
    clearFilters: "ফিল্টার পরিষ্কার করুন",
    categories: {
      salary: "বেতন",
      business: "ব্যবসা",
      investment: "বিনিয়োগ",
      other: "অন্যান্য",
      food: "খাবার",
      transport: "পরিবহন",
      utilities: "ইউটিলিটি",
      entertainment: "বিনোদন",
      healthcare: "স্বাস্থ্যসেবা",
      shopping: "শপিং"
    },
    language: "ভাষা"
  }
};

export default function Home() {
  const [language, setLanguage] = useState<"en" | "bn">("en");
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState<"ALL" | "INCOME" | "EXPENSE">("ALL");
  const [filterCategory, setFilterCategory] = useState<string>("ALL");
  const [filterFromDate, setFilterFromDate] = useState<string>("");
  const [filterToDate, setFilterToDate] = useState<string>("");
  const [formData, setFormData] = useState({
    type: "INCOME" as "INCOME" | "EXPENSE",
    amount: "",
    description: "",
    category: "",
    source: "",
    destination: "",
    date: new Date().toISOString().split('T')[0]
  });

  const t = translations[language];

  const incomeCategories = ["salary", "business", "investment", "other"];
  const expenseCategories = ["food", "transport", "utilities", "entertainment", "healthcare", "shopping"];
  const allCategories = [...incomeCategories, ...expenseCategories];

  // Filter transactions based on search and filters
  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = searchTerm === "" || 
      transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (transaction.source && transaction.source.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (transaction.destination && transaction.destination.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesType = filterType === "ALL" || transaction.type === filterType;
    const matchesCategory = filterCategory === "ALL" || transaction.category === filterCategory;
    const matchesFromDate = filterFromDate === "" || transaction.date >= filterFromDate;
    const matchesToDate = filterToDate === "" || transaction.date <= filterToDate;

    return matchesSearch && matchesType && matchesCategory && matchesFromDate && matchesToDate;
  });

  const totalIncome = filteredTransactions
    .filter(t => t.type === "INCOME")
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpense = filteredTransactions
    .filter(t => t.type === "EXPENSE")
    .reduce((sum, t) => sum + t.amount, 0);

  const balance = totalIncome - totalExpense;

  const exportData = () => {
    const csvContent = [
      ["Date", "Type", "Category", "Amount", "Description", "Source", "Destination"],
      ...filteredTransactions.map(t => [
        t.date,
        t.type,
        t.category,
        t.amount.toString(),
        t.description,
        t.source || "",
        t.destination || ""
      ])
    ].map(row => row.join(",")).join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `transactions_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  const clearFilters = () => {
    setSearchTerm("");
    setFilterType("ALL");
    setFilterCategory("ALL");
    setFilterFromDate("");
    setFilterToDate("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const newTransaction: Transaction = {
      id: Date.now().toString(),
      type: formData.type,
      amount: parseFloat(formData.amount),
      description: formData.description,
      category: formData.category,
      source: formData.type === "INCOME" ? formData.source : undefined,
      destination: formData.type === "EXPENSE" ? formData.destination : undefined,
      date: formData.date,
      createdAt: new Date().toISOString()
    };

    setTransactions([newTransaction, ...transactions]);
    
    // Reset form
    setFormData({
      type: "INCOME",
      amount: "",
      description: "",
      category: "",
      source: "",
      destination: "",
      date: new Date().toISOString().split('T')[0]
    });
  };

  const currentCategories = formData.type === "INCOME" ? incomeCategories : expenseCategories;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-800 mb-2">{t.title}</h1>
            <p className="text-gray-600">{t.subtitle}</p>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium">{t.language}</span>
            <Switch
              checked={language === "bn"}
              onCheckedChange={(checked) => setLanguage(checked ? "bn" : "en")}
            />
            <span className="text-sm font-medium">EN</span>
          </div>
        </div>

        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-green-50 border-green-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-green-700">{t.totalIncome}</CardTitle>
              <TrendingUp className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-700">৳{totalIncome.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card className="bg-red-50 border-red-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-red-700">{t.totalExpense}</CardTitle>
              <TrendingDown className="h-4 w-4 text-red-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-700">৳{totalExpense.toFixed(2)}</div>
            </CardContent>
          </Card>

          <Card className={`${balance >= 0 ? 'bg-blue-50 border-blue-200' : 'bg-orange-50 border-orange-200'}`}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className={`text-sm font-medium ${balance >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>
                {t.balance}
              </CardTitle>
              <DollarSign className={`h-4 w-4 ${balance >= 0 ? 'text-blue-600' : 'text-orange-600'}`} />
            </CardHeader>
            <CardContent>
              <div className={`text-2xl font-bold ${balance >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>
                ৳{balance.toFixed(2)}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Add Transaction Form */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {formData.type === "INCOME" ? (
                  <>
                    <PlusCircle className="h-5 w-5 text-green-600" />
                    <span className="text-green-700">{t.income}</span>
                  </>
                ) : (
                  <>
                    <MinusCircle className="h-5 w-5 text-red-600" />
                    <span className="text-red-700">{t.expense}</span>
                  </>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="flex space-x-4">
                  <Button
                    type="button"
                    variant={formData.type === "INCOME" ? "default" : "outline"}
                    className="flex-1"
                    onClick={() => setFormData({...formData, type: "INCOME"})}
                  >
                    {t.income}
                  </Button>
                  <Button
                    type="button"
                    variant={formData.type === "EXPENSE" ? "default" : "outline"}
                    className="flex-1"
                    onClick={() => setFormData({...formData, type: "EXPENSE"})}
                  >
                    {t.expense}
                  </Button>
                </div>

                <div>
                  <Label htmlFor="amount">{t.amount}</Label>
                  <Input
                    id="amount"
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={formData.amount}
                    onChange={(e) => setFormData({...formData, amount: e.target.value})}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="category">{t.category}</Label>
                  <Select value={formData.category} onValueChange={(value) => setFormData({...formData, category: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder={t.category} />
                    </SelectTrigger>
                    <SelectContent>
                      {currentCategories.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {t.categories[cat]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {formData.type === "INCOME" && (
                  <div>
                    <Label htmlFor="source">{t.source}</Label>
                    <Input
                      id="source"
                      placeholder={t.source}
                      value={formData.source}
                      onChange={(e) => setFormData({...formData, source: e.target.value})}
                    />
                  </div>
                )}

                {formData.type === "EXPENSE" && (
                  <div>
                    <Label htmlFor="destination">{t.destination}</Label>
                    <Input
                      id="destination"
                      placeholder={t.destination}
                      value={formData.destination}
                      onChange={(e) => setFormData({...formData, destination: e.target.value})}
                    />
                  </div>
                )}

                <div>
                  <Label htmlFor="description">{t.description}</Label>
                  <Textarea
                    id="description"
                    placeholder={t.description}
                    value={formData.description}
                    onChange={(e) => setFormData({...formData, description: e.target.value})}
                  />
                </div>

                <div>
                  <Label htmlFor="date">{t.date}</Label>
                  <Input
                    id="date"
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({...formData, date: e.target.value})}
                    required
                  />
                </div>

                <Button type="submit" className="w-full">
                  {t.addTransaction}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Recent Transactions */}
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>{t.recentTransactions}</CardTitle>
                <Button variant="outline" size="sm" onClick={exportData}>
                  <Download className="h-4 w-4 mr-2" />
                  {t.exportData}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {/* Filters */}
              <div className="space-y-4 mb-6">
                <div className="flex items-center space-x-2">
                  <Search className="h-4 w-4" />
                  <Input
                    placeholder={t.search}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="flex-1"
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Select value={filterType} onValueChange={(value: "ALL" | "INCOME" | "EXPENSE") => setFilterType(value)}>
                    <SelectTrigger>
                      <SelectValue placeholder={t.allTypes} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ALL">{t.allTypes}</SelectItem>
                      <SelectItem value="INCOME">{t.income}</SelectItem>
                      <SelectItem value="EXPENSE">{t.expense}</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={filterCategory} onValueChange={setFilterCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder={t.allCategories} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ALL">{t.allCategories}</SelectItem>
                      {allCategories.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {t.categories[cat as keyof typeof t.categories]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <div>
                    <Label htmlFor="fromDate">{t.fromDate}</Label>
                    <Input
                      id="fromDate"
                      type="date"
                      value={filterFromDate}
                      onChange={(e) => setFilterFromDate(e.target.value)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="toDate">{t.toDate}</Label>
                    <Input
                      id="toDate"
                      type="date"
                      value={filterToDate}
                      onChange={(e) => setFilterToDate(e.target.value)}
                    />
                  </div>
                </div>

                <Button variant="outline" size="sm" onClick={clearFilters}>
                  <Filter className="h-4 w-4 mr-2" />
                  {t.clearFilters}
                </Button>
              </div>

              {filteredTransactions.length === 0 ? (
                <p className="text-gray-500 text-center py-8">{t.noTransactions}</p>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {filteredTransactions.map((transaction) => (
                    <div key={transaction.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          {transaction.type === "INCOME" ? (
                            <PlusCircle className="h-4 w-4 text-green-600" />
                          ) : (
                            <MinusCircle className="h-4 w-4 text-red-600" />
                          )}
                          <Badge variant={transaction.type === "INCOME" ? "default" : "destructive"}>
                            {transaction.type === "INCOME" ? t.income : t.expense}
                          </Badge>
                        </div>
                        <span className={`font-bold ${transaction.type === "INCOME" ? 'text-green-700' : 'text-red-700'}`}>
                          {transaction.type === "INCOME" ? '+' : '-'}৳{transaction.amount.toFixed(2)}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 mb-1">{transaction.description}</p>
                      <p className="text-xs text-gray-500 mb-1">
                        {t.categories[transaction.category as keyof typeof t.categories]}
                      </p>
                      {transaction.source && (
                        <p className="text-xs text-gray-500 mb-1">
                          <User className="inline h-3 w-3 mr-1" />
                          {transaction.source}
                        </p>
                      )}
                      {transaction.destination && (
                        <p className="text-xs text-gray-500 mb-1">
                          <MapPin className="inline h-3 w-3 mr-1" />
                          {transaction.destination}
                        </p>
                      )}
                      <p className="text-xs text-gray-500">
                        <Calendar className="inline h-3 w-3 mr-1" />
                        {new Date(transaction.date).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}